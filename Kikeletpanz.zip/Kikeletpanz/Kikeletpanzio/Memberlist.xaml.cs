﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Kikeletpanzio
{
    /// <summary>
    /// Interaction logic for Memberlist.xaml
    /// </summary>
    public partial class Memberlist : Window
    {
        internal static List<Taglista> tagok = new List<Taglista>();
        internal static List<Foglalasadat> foglalasadatok = new List<Foglalasadat>();
        Osszmegszallt ujablak;
        public static int selectedIndex = -1;


        public Memberlist()
        {
            

            string[] sorok = File.ReadAllLines("Memberlist.txt");


            // feltöltés
            for (int i = 1; i < sorok.Length; i++)
            {
                tagok.Add(new Taglista(sorok[i]));
            }

           

            string[] sor = File.ReadAllLines("Foglalasadat.txt");

            for (int i = 1; i < sorok.Length; i++)
            {
                foglalasadatok.Add(new Foglalasadat(sor[i]));
            }

            InitializeComponent();

            dtgrd.ItemsSource = tagok;
            dtgrd1.ItemsSource = foglalasadatok;

        }

        private void osszszallobtn_Click(object sender, RoutedEventArgs e)
        {
            ujablak = new Osszmegszallt();
            ujablak.ShowDialog();
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void kijelentkezes_Click(object sender, RoutedEventArgs e)
        {
            string filePath = "output.txt";
            SaveDataGridsToTxt(dtgrd, dtgrd1, filePath);
            MessageBox.Show("Data saved successfully to " + filePath);
        }

        private void SaveDataGridsToTxt(DataGrid dataGrid1, DataGrid dataGrid2, string filePath)
        {
            if (dataGrid1 == null && dataGrid2 == null)
            {
                return; // Ha mindkét DataGrid üres vagy null, térjünk vissza
            }

            StringBuilder sb = new StringBuilder();

            if (dataGrid1 != null && dataGrid1.Items.Count > 0)
            {
                // Adatok kiolvasása az első DataGrid-ből
                AppendDataGridData(dataGrid1, sb);
            }

            // Két DataGrid adatai közé opcionálisan elválasztó karaktereket tehetünk, pl. új sort
            if (dataGrid1 != null && dataGrid1.Items.Count > 0 && dataGrid2 != null && dataGrid2.Items.Count > 0)
            {
                sb.AppendLine();
                sb.AppendLine(";"); // Eltérő DataGrid jelzése
            }

            if (dataGrid2 != null && dataGrid2.Items.Count > 0)
            {
                // Adatok kiolvasása a második DataGrid-ből
                AppendDataGridData(dataGrid2, sb);
            }

            // Adatok mentése fájlba
            File.WriteAllText(filePath, sb.ToString());
        }

        private void AppendDataGridData(DataGrid dataGrid, StringBuilder sb)
        {
            if (dataGrid == null || dataGrid.Columns.Count == 0 || dataGrid.Items.Count == 0)
            {
                return; // Ha a DataGrid üres vagy null, térjünk vissza
            }

            // Fejléc kiolvasása
            foreach (var column in dataGrid.Columns)
            {
                sb.Append(column.Header);
                sb.Append("\t");
            }
            sb.AppendLine();

            // Sorok kiolvasása
            foreach (var item in dataGrid.Items)
            {
                // Ellenőrizze, hogy az aktuális sor nem üres (pl. üres sor esetén)
                if (item is not null && item.GetType() != typeof(System.Data.DataRowView))
                {
                    var properties = item.GetType().GetProperties();
                    for (int i = 0; i < properties.Length; i++)
                    {
                        var propValue = properties[i].GetValue(item, null);
                        sb.Append(propValue != null ? propValue.ToString() : string.Empty);
                        if (i < properties.Length - 1)
                        {
                            sb.Append("\t");
                        }
                    }
                    sb.AppendLine();
                }
            }
        }

            private void dtgrd_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedIndex = dtgrd.SelectedIndex;
        }

        private void dtgrd1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedIndex = dtgrd1.SelectedIndex;
        }
    }
    }
    

