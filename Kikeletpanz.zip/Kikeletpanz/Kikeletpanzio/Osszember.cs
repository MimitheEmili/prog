﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kikeletpanzio
{
    internal class Osszember
    {
        string vezeteknev;
        string keresztnev;
        string email;
        int telefonszam;
        string orszag;
        string telepules;
        bool vip;
        int felnottfo;
        int gyerekfo;
        DateTime erkezes;
        DateTime tavozas;
        bool reggeli;
        bool vacsora;
        bool pluszagy;
        bool babaagy;
        bool tiltott;

        


        public Osszember(string sor)
        {
            string[] bontas = sor.Split(';');
            Vezeteknev = bontas[0];
            Keresztnev = bontas[1];
            Email = bontas[2];
            Telefonszam = int.Parse(bontas[3]);
            Orszag = bontas[4];
            Telepules = bontas[5];
            Vip = bool.Parse(bontas[6]);
            Felnottfo = int.Parse(bontas[7]);
            Gyerekfo = int.Parse(bontas[8]);
            Erkezes = DateTime.Parse(bontas[9]);
            Tavozas = DateTime.Parse(bontas[10]);
            Reggeli = bool.Parse(bontas[11]);
            Vacsora = bool.Parse(bontas[12]);
            Pluszagy = bool.Parse(bontas[13]);
            Babaagy = bool.Parse(bontas[14]);
            Tiltott = bool.Parse(bontas[15]);
        }

        public Osszember(string vezeteknev, string keresztnev, string email, int telefonszam, string orszag, string telepules, bool vip, int felnottfo, int gyerekfo, DateTime erkezes, DateTime tavozas, bool reggeli, bool vacsora, bool pluszagy, bool babaagy, bool tiltott)
        {
            this.Vezeteknev = vezeteknev;
            this.Keresztnev = keresztnev;
            this.Email = email;
            this.Telefonszam = telefonszam;
            this.Orszag = orszag;
            this.Telepules = telepules;
            this.Vip = vip;
            this.Felnottfo = felnottfo;
            this.Gyerekfo = gyerekfo;
            this.Erkezes = erkezes;
            this.Tavozas = tavozas;
            this.Reggeli = reggeli;
            this.Vacsora = vacsora;
            this.Pluszagy = pluszagy;
            this.Babaagy = babaagy;
            this.Tiltott = tiltott;
        }

        public string Vezeteknev { get => vezeteknev; set => vezeteknev = value; }
        public string Keresztnev { get => keresztnev; set => keresztnev = value; }
        public string Email { get => email; set => email = value; }
        public int Telefonszam { get => telefonszam; set => telefonszam = value; }
        public string Orszag { get => orszag; set => orszag = value; }
        public string Telepules { get => telepules; set => telepules = value; }
        public bool Vip { get => vip; set => vip = value; }
        public int Felnottfo { get => felnottfo; set => felnottfo = value; }
        public int Gyerekfo { get => gyerekfo; set => gyerekfo = value; }
        public DateTime Erkezes { get => erkezes; set => erkezes = value; }
        public DateTime Tavozas { get => tavozas; set => tavozas = value; }
        public bool Reggeli { get => reggeli; set => reggeli = value; }
        public bool Vacsora { get => vacsora; set => vacsora = value; }
        public bool Pluszagy { get => pluszagy; set => pluszagy = value; }
        public bool Babaagy { get => babaagy; set => babaagy = value; }
        public bool Tiltott { get => tiltott; set => tiltott = value; }
    }
}
