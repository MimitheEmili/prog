﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Kikeletpanzio
{
    /// <summary>
    /// Interaction logic for Bejelentkezes.xaml
    /// </summary>
    public partial class Bejelentkezes : Window
    {
        internal static List<Taglista> tagok = new List<Taglista>();
        Foglalas ujablak;
        
        public Bejelentkezes()
        {
            InitializeComponent();
        }

        private void Accept_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(vezeteknevtbx.Text) ||
        string.IsNullOrWhiteSpace(keresztnevtbx.Text) ||
        string.IsNullOrWhiteSpace(Emailtbx.Text) ||
        string.IsNullOrWhiteSpace(Telefonszamtbx.Text) ||
        string.IsNullOrWhiteSpace(Orszagtbx.Text) ||
        string.IsNullOrWhiteSpace(Telepulestbx.Text) ||
        !Viprdn.IsChecked.HasValue || !Viprdn.IsChecked.Value)
            {
                MessageBox.Show("Kérjük, töltsön ki minden mezőt.", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            Taglista ujtag = new Taglista(vezeteknevtbx.Text, keresztnevtbx.Text, Emailtbx.Text, int.Parse(Telefonszamtbx.Text), Orszagtbx.Text, Telepulestbx.Text, Viprdn.IsChecked.Value);
            Memberlist.tagok.Add(ujtag);

            try
                
            {
                string filePath = "Memberlist.txt";
                using (StreamWriter kimenet = new StreamWriter(filePath,true))
                {
                    foreach (Taglista tag in Memberlist.tagok)
                    {
                        kimenet.WriteLine(tag.MentesToString());
                    }
                }

                MessageBox.Show("Adatok sikeresen elmentve.", "Sikeres mentés", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba történt a fájl írása közben: {ex.Message}", "Hiba", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            ujablak = new Foglalas();
            ujablak.ShowDialog();

        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
