﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Kikeletpanzio
{
    /// <summary>
    /// Interaction logic for Osszmegszallt.xaml
    /// </summary>
    public partial class Osszmegszallt : Window
    {
        List<Osszember> ossztag = new List<Osszember>();
        public Osszmegszallt()
        {
            InitializeComponent();
            dtgrd.ItemsSource = ossztag;
            string[] sorok = File.ReadAllLines("Osszembertag.txt");
            for (int i = 0; i < sorok.Length; i++)
            {
                ossztag.Add(new Osszember(sorok[i]));
            }
        }
        private void Back_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
