﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Zoldseges
{
    /// <summary>
    /// Interaction logic for UjAru.xaml
    /// </summary>
    public partial class UjAru : Window
    {
        public UjAru()
        {
            InitializeComponent();
        }

        private void Btnmentes_Click3(object sender, RoutedEventArgs e)
        {
            Aru ujAru = new Aru(Tbxnev2.Text, int.Parse(Tbxar2.Text), Cbxujakcio.IsChecked.Value);
            MainWindow.aruk.Add(ujAru);
            Close();
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {

        }
    }
}
