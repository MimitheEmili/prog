﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoldseges
{
    internal class Aru
    {
        string nev;
        int ar;
        bool akcios;

        public Aru(string nev, int aru, bool akcios = false)
        {
            Nev = nev;
            Ar = aru;
            Akcios = akcios;
        }

        public string Nev { get => nev; set => nev = value; }
        public int Ar { get => ar; set => ar = value; }
        public bool Akcios { get => akcios; set => akcios = value; }
        public double AkciosAr { get => akcios ? ((int)Math.Round(0.9 * Ar)) : Ar; }
        
        public Aru(string sor)
        {
            string[] bontas = sor.Split(';');
            nev = bontas[0];
            ar = int.Parse(bontas[1]);
        }
        public string AllomanybaToString()
        {
            return $"{nev};{ar}";
        }
    }
}
