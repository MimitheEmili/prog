﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Zoldseges
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    
    {
        internal static List<Aru> aruk = new List<Aru>();
        UjAru ujaruablak;
        public MainWindow()
        {
            string[] bontas = File.ReadAllLines("termekek.txt");
            string[] akcios = File.ReadAllLines("akcio.txt");
            foreach (string sor in bontas)
            {
                aruk.Add(new Aru(sor));
                if(akcios.Contains(aruk.Last().Nev))
                {
                    aruk.Last().Akcios = true;
                }
            }

            InitializeComponent();

            Dgraru.ItemsSource = aruk;


        }

        private void Dgraru_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Tbxnev.Text = aruk[Dgraru.SelectedIndex].Nev;
            Tbxar.Text = aruk[Dgraru.SelectedIndex].Ar.ToString();
        }

        private void Btnmentes_Click(object sender, RoutedEventArgs e)
        {
            aruk[Dgraru.SelectedIndex].Nev = Tbxnev.Text;
            aruk[Dgraru.SelectedIndex].Ar = int.Parse(Tbxar.Text);
            Dgraru.Items.Refresh();
        }

        private void Btnmentes_Click2(object sender, RoutedEventArgs e)
        {
            StreamWriter kimenet = new StreamWriter("termekek.txt");
            foreach (Aru aru in aruk)
            {
                kimenet.WriteLine(aru.AllomanybaToString());
            }
            kimenet.Close();
        }

        private void Cbxakcios_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void Btnmentes_Click3(object sender, RoutedEventArgs e)
        {
            ujaruablak = new UjAru();
            ujaruablak.ShowDialog();
            Dgraru.Items.Refresh();
        }
    }
}
