﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Kikeletpanzio
{
    /// <summary>
    /// Interaction logic for Foglalas.xaml
    /// </summary>
    public partial class Foglalas : Window
    {
        Elsoszoba ujablak;
        Masodikszoba ujablak2;
        Harmadikszoba ujablak3;
        Negyedikszoba ujablak4;
        Otodikszoba ujablak5;
        Hatodikszoba ujablak6;

        
        public Foglalas()
        {
            InitializeComponent();
        }

        private void egybtn_Click(object sender, RoutedEventArgs e)
        {
            ujablak = new Elsoszoba();
            ujablak.ShowDialog();
        }

        private void kettobtn_Click(object sender, RoutedEventArgs e)
        {
            ujablak2 = new Masodikszoba();
            ujablak2.ShowDialog();
        }

        private void harombtn_Click(object sender, RoutedEventArgs e)
        {
            ujablak3 = new Harmadikszoba();
            ujablak3.ShowDialog();
        }

        private void negybtn_Click(object sender, RoutedEventArgs e)
        {
            ujablak4 = new Negyedikszoba();
            ujablak4.ShowDialog();
        }

        private void otbtn_Click(object sender, RoutedEventArgs e)
        {
            ujablak5 = new Otodikszoba();
            ujablak5.ShowDialog();
        }

        private void hatbtn_Click(object sender, RoutedEventArgs e)
        {
            ujablak6 = new Hatodikszoba();
            ujablak6.ShowDialog();
        }
    }
}
