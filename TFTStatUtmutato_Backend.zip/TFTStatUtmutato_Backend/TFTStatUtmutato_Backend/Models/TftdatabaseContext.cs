﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace TFTStatUtmutato_Backend.Models;

public partial class TftdatabaseContext : DbContext
{
    public TftdatabaseContext()
    {
    }

    public TftdatabaseContext(DbContextOptions<TftdatabaseContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Augment> Augments { get; set; }

    public virtual DbSet<Character> Characters { get; set; }

    public virtual DbSet<Class> Classes { get; set; }

    public virtual DbSet<Classlevelbonu> Classlevelbonus { get; set; }

    public virtual DbSet<Fullitem> Fullitems { get; set; }

    public virtual DbSet<Partialitem> Partialitems { get; set; }

    public virtual DbSet<Permission> Permissions { get; set; }

    public virtual DbSet<Portal> Portals { get; set; }

    public virtual DbSet<User> Users { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseMySQL("SERVER=localhost;PORT=3306;DATABASE=tftdatabase;USER=root;PASSWORD=;SSL MODE=none;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Augment>(entity =>
        {
            entity.HasKey(e => e.AugmentId).HasName("PRIMARY");

            entity.ToTable("augments");

            entity.Property(e => e.AugmentId)
                .HasColumnType("int(11)")
                .HasColumnName("AugmentID");
            entity.Property(e => e.Effect)
                .HasDefaultValueSql("'NULL'")
                .HasColumnType("text");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.Rarity).HasMaxLength(15);
        });

        modelBuilder.Entity<Character>(entity =>
        {
            entity.HasKey(e => e.CharacterId).HasName("PRIMARY");

            entity.ToTable("character");

            entity.Property(e => e.CharacterId)
                .HasColumnType("int(11)")
                .HasColumnName("CharacterID");
            entity.Property(e => e.Ability)
                .HasDefaultValueSql("'NULL'")
                .HasColumnType("text");
            entity.Property(e => e.AbilityPower)
                .HasDefaultValueSql("'NULL'")
                .HasColumnType("int(11)");
            entity.Property(e => e.Armor)
                .HasDefaultValueSql("'NULL'")
                .HasColumnType("int(11)");
            entity.Property(e => e.AttackDamage)
                .HasDefaultValueSql("'NULL'")
                .HasColumnType("int(11)");
            entity.Property(e => e.AttackSpeed).HasDefaultValueSql("'NULL'");
            entity.Property(e => e.CharacterName).HasMaxLength(50);
            entity.Property(e => e.Cost)
                .HasDefaultValueSql("'NULL'")
                .HasColumnType("int(11)");
            entity.Property(e => e.DamagePerSec)
                .HasDefaultValueSql("'NULL'")
                .HasColumnType("int(11)");
            entity.Property(e => e.Health)
                .HasDefaultValueSql("'NULL'")
                .HasColumnType("int(11)");
            entity.Property(e => e.MagicResist)
                .HasDefaultValueSql("'NULL'")
                .HasColumnType("int(11)");
            entity.Property(e => e.ManaMax)
                .HasDefaultValueSql("'NULL'")
                .HasColumnType("int(11)");
            entity.Property(e => e.ManaStart)
                .HasDefaultValueSql("'NULL'")
                .HasColumnType("int(11)");
            entity.Property(e => e.Rangee)
                .HasDefaultValueSql("'NULL'")
                .HasColumnType("int(11)");

            entity.HasMany(d => d.Classes).WithMany(p => p.Characters)
                .UsingEntity<Dictionary<string, object>>(
                    "Characterclass",
                    r => r.HasOne<Class>().WithMany()
                        .HasForeignKey("ClassId")
                        .HasConstraintName("characterclass_ibfk_2"),
                    l => l.HasOne<Character>().WithMany()
                        .HasForeignKey("CharacterId")
                        .OnDelete(DeleteBehavior.Restrict)
                        .HasConstraintName("characterclass_ibfk_1"),
                    j =>
                    {
                        j.HasKey("CharacterId", "ClassId").HasName("PRIMARY");
                        j.ToTable("characterclass");
                        j.HasIndex(new[] { "ClassId" }, "ClassID");
                        j.IndexerProperty<int>("CharacterId")
                            .HasColumnType("int(11)")
                            .HasColumnName("CharacterID");
                        j.IndexerProperty<int>("ClassId")
                            .HasColumnType("int(11)")
                            .HasColumnName("ClassID");
                    });
        });

        modelBuilder.Entity<Class>(entity =>
        {
            entity.HasKey(e => e.ClassId).HasName("PRIMARY");

            entity.ToTable("class");

            entity.Property(e => e.ClassId)
                .HasColumnType("int(11)")
                .HasColumnName("ClassID");
            entity.Property(e => e.BasicEffect)
                .HasDefaultValueSql("'NULL'")
                .HasColumnType("text");
            entity.Property(e => e.ClassName).HasMaxLength(50);
        });

        modelBuilder.Entity<Classlevelbonu>(entity =>
        {
            entity.HasKey(e => new { e.ClassId, e.Level }).HasName("PRIMARY");

            entity.ToTable("classlevelbonus");

            entity.Property(e => e.ClassId)
                .HasColumnType("int(11)")
                .HasColumnName("ClassID");
            entity.Property(e => e.Level).HasColumnType("int(11)");
            entity.Property(e => e.BonusEffect)
                .HasDefaultValueSql("'NULL'")
                .HasColumnType("text");
            entity.Property(e => e.CharacterCount)
                .HasDefaultValueSql("'NULL'")
                .HasColumnType("int(11)");

            entity.HasOne(d => d.Class).WithMany(p => p.Classlevelbonus)
                .HasForeignKey(d => d.ClassId)
                .OnDelete(DeleteBehavior.Restrict)
                .HasConstraintName("classlevelbonus_ibfk_1");
        });

        modelBuilder.Entity<Fullitem>(entity =>
        {
            entity.HasKey(e => e.FullItemId).HasName("PRIMARY");

            entity.ToTable("fullitems");

            entity.Property(e => e.FullItemId)
                .HasColumnType("int(11)")
                .HasColumnName("full_item_id");
            entity.Property(e => e.ActiveEffect)
                .HasDefaultValueSql("'NULL'")
                .HasColumnType("text");
            entity.Property(e => e.Effect)
                .HasDefaultValueSql("'NULL'")
                .HasColumnType("text")
                .HasColumnName("effect");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .HasColumnName("name");

            entity.HasMany(d => d.PartialItems).WithMany(p => p.FullItems)
                .UsingEntity<Dictionary<string, object>>(
                    "Fullitemcomponent",
                    r => r.HasOne<Partialitem>().WithMany()
                        .HasForeignKey("PartialItemId")
                        .OnDelete(DeleteBehavior.Restrict)
                        .HasConstraintName("fullitemcomponents_ibfk_2"),
                    l => l.HasOne<Fullitem>().WithMany()
                        .HasForeignKey("FullItemId")
                        .OnDelete(DeleteBehavior.Restrict)
                        .HasConstraintName("fullitemcomponents_ibfk_1"),
                    j =>
                    {
                        j.HasKey("FullItemId", "PartialItemId").HasName("PRIMARY");
                        j.ToTable("fullitemcomponents");
                        j.HasIndex(new[] { "PartialItemId" }, "partial_item_id");
                        j.IndexerProperty<int>("FullItemId")
                            .HasColumnType("int(11)")
                            .HasColumnName("full_item_id");
                        j.IndexerProperty<int>("PartialItemId")
                            .HasColumnType("int(11)")
                            .HasColumnName("partial_item_id");
                    });
        });

        modelBuilder.Entity<Partialitem>(entity =>
        {
            entity.HasKey(e => e.PartialItemId).HasName("PRIMARY");

            entity.ToTable("partialitems");

            entity.Property(e => e.PartialItemId)
                .HasColumnType("int(11)")
                .HasColumnName("partial_item_id");
            entity.Property(e => e.Effect)
                .HasDefaultValueSql("'NULL'")
                .HasColumnType("text")
                .HasColumnName("effect");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .HasColumnName("name");
        });

        modelBuilder.Entity<Permission>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("permission");

            entity.HasIndex(e => e.Name, "Nev").IsUnique();

            entity.HasIndex(e => e.Level, "Szint").IsUnique();

            entity.Property(e => e.Id).HasColumnType("int(11)");
            entity.Property(e => e.Description).HasMaxLength(100);
            entity.Property(e => e.Level).HasColumnType("int(1)");
            entity.Property(e => e.Name).HasMaxLength(32);
        });

        modelBuilder.Entity<Portal>(entity =>
        {
            entity.HasKey(e => e.PortalId).HasName("PRIMARY");

            entity.ToTable("portals");

            entity.Property(e => e.PortalId)
                .HasColumnType("int(11)")
                .HasColumnName("portal_id");
            entity.Property(e => e.Effect)
                .HasDefaultValueSql("'NULL'")
                .HasColumnType("text")
                .HasColumnName("effect");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .HasColumnName("name");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("user");

            entity.HasIndex(e => e.Email, "Email").IsUnique();

            entity.HasIndex(e => e.PermissionId, "Jog");

            entity.HasIndex(e => e.LoginName, "LoginNev").IsUnique();

            entity.Property(e => e.Id).HasColumnType("int(11)");
            entity.Property(e => e.Email).HasMaxLength(64);
            entity.Property(e => e.Hash)
                .HasMaxLength(64)
                .HasColumnName("HASH");
            entity.Property(e => e.LoginName).HasMaxLength(16);
            entity.Property(e => e.Name).HasMaxLength(64);
            entity.Property(e => e.PermissionId).HasColumnType("int(11)");
            entity.Property(e => e.ProfilePicturePath).HasMaxLength(64);
            entity.Property(e => e.Salt)
                .HasMaxLength(64)
                .HasColumnName("SALT");

            entity.HasOne(d => d.Permission).WithMany(p => p.Users)
                .HasForeignKey(d => d.PermissionId)
                .HasConstraintName("user_ibfk_1");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
