﻿using System;
using System.Collections.Generic;

namespace TFTStatUtmutato_Backend.Models;

public partial class Fullitem
{
    public int FullItemId { get; set; }

    public string Name { get; set; } = null!;

    public string? Effect { get; set; }

    public string? ActiveEffect { get; set; }

    public virtual ICollection<Partialitem> PartialItems { get; set; } = new List<Partialitem>();
}
