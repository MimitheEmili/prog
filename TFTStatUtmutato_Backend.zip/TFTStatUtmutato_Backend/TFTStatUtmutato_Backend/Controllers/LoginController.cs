﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TFTStatUtmutato_Backend.DTOs;
using TFTStatUtmutato_Backend.Models;

namespace TFTStatUtmutato_Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        [HttpPost("SaltRequest/{LoginNev}")]
        public async Task<IActionResult> SaltRequest(string LoginNev)
        {
            using (var cx = new TftdatabaseContext())
            {
                try
                {
                    User response = await cx.Users.FirstOrDefaultAsync(f => f.LoginName == LoginNev);
                    if (response == null)
                    {
                        return BadRequest("Hiba");
                    }
                    return Ok(response.Salt);

                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }

        }
        [HttpPost]

        public async Task<IActionResult> Login(LoginDTO loginDTO)
        {
            using (var cx = new TftdatabaseContext())
            {
                try
                {
                    string Hash = TFTStatUtmutato_Backend.Program.CreateSHA256(loginDTO.TmpHash);
                    User loggedUser = await cx.Users.FirstOrDefaultAsync(f => f.LoginName == loginDTO.LoginNev && f.Hash == Hash);
                    if (loggedUser != null && loggedUser.Active)
                    {
                        string token = Guid.NewGuid().ToString();
                        lock (Program.LoggedInUsers)
                        {
                            Program.LoggedInUsers.Add(token,loggedUser);
                        }
                        return Ok(new LoggedUser { Name = loggedUser.Name, Email = loggedUser.Email, Permission = loggedUser.PermissionId, ProfilePicturePath = loggedUser.ProfilePicturePath, Token = token });
                    }
                    else
                    {
                        return BadRequest("Hibás név vagy jelszó/inaktív felhasználó!");
                    }

                }
                catch (Exception ex)
                {
                    return BadRequest(new LoggedUser { Permission = -1, Name = ex.Message, ProfilePicturePath = "", Email = "" });
                }
            }
        }
    }
}
