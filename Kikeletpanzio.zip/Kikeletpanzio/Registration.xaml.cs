﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Kikeletpanzio
{
    /// <summary>
    /// Interaction logic for Registration.xaml
    /// </summary>
    public partial class Registration : Window
    {
        List<Adatok> registrations = new List<Adatok>();
        public Registration()
        {
            string[] bontas = File.ReadAllLines("registracio.txt");
            foreach (string sor in bontas)
            {
                registrations.Add(new Adatok(sor));
            }
            InitializeComponent();
        }


        private void Accept_Click(object sender, RoutedEventArgs e)
        {
            StreamWriter kimenet = new StreamWriter("registracio.txt");
            foreach (Adatok regist in registrations)
            {
                kimenet.WriteLine(regist.Mentes());
            }
            kimenet.Close();
        }
    }
}
