﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Kikeletpanzio
{
    /// <summary>
    /// Interaction logic for Memberlist.xaml
    /// </summary>
    public partial class Memberlist : Window
    {
        Osszmegszallt ujablak;
        Tiltottak ujablak1;
        public Memberlist()
        {
            InitializeComponent();
        }

        private void osszszallobtn_Click(object sender, RoutedEventArgs e)
        {
            ujablak = new Osszmegszallt();
            ujablak.ShowDialog();
        }

        private void tiltottbtn_Click(object sender, RoutedEventArgs e)
        {
            ujablak1 = new Tiltottak();
            ujablak1.ShowDialog();
        }
    }
}
