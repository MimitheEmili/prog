﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Kikeletpanzio
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Registration ujablak;
        Memberlist ujablak2;
        Statistic ujablak3;
        Foglalas ujablak4;
        
        public MainWindow()
        {
            InitializeComponent();
        }

        private void registration_Click(object sender, RoutedEventArgs e)
        {
            ujablak = new Registration();
            ujablak.ShowDialog();
        }

        private void Memberlist_Click(object sender, RoutedEventArgs e)
        {
            ujablak2 = new Memberlist();
            ujablak2.ShowDialog();
        }

        private void Statistic_Click(object sender, RoutedEventArgs e)
        {
            ujablak3 = new Statistic();
            ujablak3.ShowDialog();
        }

        private void Foglalas_Click(object sender, RoutedEventArgs e)
        {
            ujablak4 = new Foglalas();
            ujablak4.ShowDialog();
        }
    }
}