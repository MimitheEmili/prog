﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kikeletpanzio
{
    class Adatok
    {
        string vezeteknev;
        string keresztnev;
        string email;
        int telefonszam;
        string orszag;
        int iranyito;
        string telepules;
        string utcahazszam;

        public Adatok(string vezeteknev, string keresztnev, string email, int telefonszam, string orszag, int iranyito, string telepules, string utcahazszam)
        {
            this.Vezeteknev = vezeteknev;
            this.Keresztnev = keresztnev;
            this.Email = email;
            this.Telefonszam = telefonszam;
            this.Orszag = orszag;
            this.Iranyito = iranyito;
            this.Telepules = telepules;
            this.Utcahazszam = utcahazszam;
        }

        public string Vezeteknev { get => vezeteknev; set => vezeteknev = value; }
        public string Keresztnev { get => keresztnev; set => keresztnev = value; }
        public string Email { get => email; set => email = value; }
        public int Telefonszam { get => telefonszam; set => telefonszam = value; }
        public string Orszag { get => orszag; set => orszag = value; }
        public int Iranyito { get => iranyito; set => iranyito = value; }
        public string Telepules { get => telepules; set => telepules = value; }
        public string Utcahazszam { get => utcahazszam; set => utcahazszam = value; }


        public Adatok(string sor)
        {
            string[] bontas = sor.Split(';');
            vezeteknev = bontas[0];
            keresztnev = bontas[1];
            email = bontas[2];
            telefonszam = int.Parse(bontas[3]);
            orszag = bontas[4];
            iranyito = int.Parse(bontas[5]);
            telepules = bontas[6];
            utcahazszam = bontas[7];
        }
        public string Mentes()
        {
            return $"{vezeteknev};{keresztnev};{email};{telefonszam};{orszag};{iranyito};{telepules};{utcahazszam}";
        }
    }

    
}
