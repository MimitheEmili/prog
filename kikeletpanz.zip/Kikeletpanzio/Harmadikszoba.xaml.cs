﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Kikeletpanzio
{
    /// <summary>
    /// Interaction logic for Harmadikszoba.xaml
    /// </summary>
    public partial class Harmadikszoba : Window
    {
        public Harmadikszoba()
        {
            InitializeComponent();
        }
        private void Back_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void adatmentesbtn_Click(object sender, RoutedEventArgs e)
        {
            bool pluszagyChecked = pluszagyrbn.IsChecked ?? false;
            bool babaagyrbnChecked = babaagyrbn.IsChecked ?? false;
            bool reggelirbnChecked = reggelirbn.IsChecked ?? false;
            bool vacsorarbnChecked = vacsorarbn.IsChecked ?? false;
            bool tiltottrbnChecked = tiltottrbn.IsChecked ?? false;

            Foglalasadat ujszallas = new Foglalasadat(int.Parse(felnotttbx.Text),
                                                       int.Parse(gyerektbx.Text),
                                                       erkezesdate.SelectedDate.Value,
                                                       tavozasdate.SelectedDate.Value,
                                                       pluszagyChecked,
                                                       babaagyrbnChecked,
                                                       reggelirbnChecked,
                                                       vacsorarbnChecked, tiltottrbnChecked);

            Memberlist.foglalasadatok.Add(ujszallas);


            
            MessageBox.Show("Az adatok sikeresen mentve lettek, 9000ft lesz.", "Sikeres mentés, 9000ft lesz", MessageBoxButton.OK, MessageBoxImage.Information);

            Close();
        }
    }
}
