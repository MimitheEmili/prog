﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kikeletpanzio
{
    class Taglista
    {
        string vezeteknev;
        string keresztnev;
        string email;
        int telefonszam;
        string orszag;
        string telepules;
        bool vip;

        public Taglista(string sor)
        {
            string[] bontas = sor.Split(';');
            Vezeteknev = bontas[0];
            Keresztnev = bontas[1];
            Email = bontas[2];
            Telefonszam = int.Parse(bontas[3]);
            Orszag = bontas[4];
            Telepules = bontas[5];
            vip = bool.Parse(bontas[6]);
        }

        public Taglista(string vezeteknev, string keresztnev, string email, int telefonszam, string orszag, string telepules, bool vip)
        {
            this.Vezeteknev = vezeteknev;
            this.Keresztnev = keresztnev;
            this.Email = email;
            this.Telefonszam = telefonszam;
            this.Orszag = orszag;
            this.Telepules = telepules;
            this.Vip = vip;
        }

        public string Vezeteknev { get => vezeteknev; set => vezeteknev = value; }
        public string Keresztnev { get => keresztnev; set => keresztnev = value; }
        public string Email { get => email; set => email = value; }
        public int Telefonszam { get => telefonszam; set => telefonszam = value; }
        public string Orszag { get => orszag; set => orszag = value; }
        public string Telepules { get => telepules; set => telepules = value; }
        public bool Vip { get => vip; set => vip = value; }

        public string MentesToString()
        {
            return $"{Vezeteknev};{Keresztnev};{Email};{Telefonszam};{Orszag};{Telepules};{Vip}";
        }

     }   
}
