﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kikeletpanzio
{
    internal class Foglalasadat
    {
        int felnottfo;
        int gyerekfo;
        DateTime erkezes;
        DateTime tavozas;
        bool reggeli;
        bool vacsora;
        bool pluszagy;
        bool babaagy;
        bool tiltott;

        public Foglalasadat(int felnottfo, int gyerekfo, DateTime erkezes, DateTime tavozas, bool reggeli, bool vacsora, bool pluszagy, bool babaagy, bool tiltott)
        {
            this.Felnottfo = felnottfo;
            this.Gyerekfo = gyerekfo;
            this.Erkezes = erkezes;
            this.Tavozas = tavozas;
            this.Reggeli = reggeli;
            this.Vacsora = vacsora;
            this.Pluszagy = pluszagy;
            this.Babaagy = babaagy;
            this.Tiltott = tiltott;
        }

        public int Felnottfo { get => felnottfo; set => felnottfo = value; }
        public int Gyerekfo { get => gyerekfo; set => gyerekfo = value; }
        public DateTime Erkezes { get => erkezes; set => erkezes = value; }
        public DateTime Tavozas { get => tavozas; set => tavozas = value; }
        public bool Reggeli { get => reggeli; set => reggeli = value; }
        public bool Vacsora { get => vacsora; set => vacsora = value; }
        public bool Pluszagy { get => pluszagy; set => pluszagy = value; }
        public bool Babaagy { get => babaagy; set => babaagy = value; }
        public bool Tiltott { get => tiltott; set => tiltott = value; }

        public Foglalasadat(string sor)
        {
            string[] bontas = sor.Split(';');
            felnottfo = int.Parse(bontas[0]);
            gyerekfo = int.Parse(bontas[1]);
            erkezes = DateTime.Parse(bontas[2]);
            tavozas = DateTime.Parse(bontas[3]);
            reggeli = bool.Parse(bontas[4]);
            vacsora = bool.Parse(bontas[5]);
            pluszagy = bool.Parse(bontas[6]);
            babaagy = bool.Parse(bontas[7]);
            tiltott = bool.Parse(bontas[8]);
        }
        public string MentesToString()
        {
            return $"{felnottfo};{gyerekfo};{erkezes};{tavozas};{reggeli};{vacsora};{pluszagy};{babaagy};{tiltott}";
        }
    }
}
